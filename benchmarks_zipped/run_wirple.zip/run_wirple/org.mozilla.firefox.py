#! /usr/bin/env python
# -*- coding: utf-8 -*-
import sys, os
sys.path.append(os.path.normpath(os.path.join(os.path.dirname(__file__), '..')))
from wirple import (wirple)
wirple()